package com.example.alphabetbook

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileWriter

class AlphabetActivity2 : AppCompatActivity() {

    var letters = Array<String>(26) { "" }  //Array string of alphabet letters
    var imgList = Array(26) { myImage() }   //Array of myImage objects
    var imgbit: Bitmap? = null
    var count = 0

    var currnIndex = -1                           //Index value of the currently viewed letter

    @SuppressLint("CommitPrefEdits")
    //Creation of Alphabet viewing activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alphabet2)// display Alphabet view page
        supportActionBar!!.setDisplayHomeAsUpEnabled(false)
        supportActionBar!!.hide() //hiding Activity bar


        var l = 65//Capital "A"
        for (i in 0..25) {
            letters[i] = Character.toString(l.toChar()) //loading letters
            l++
        }
        currnIndex =
            intent.getIntExtra("cur", 0) // getting Index value of the letter to be displayed

        var imageView = findViewById(R.id.imageView) as ImageView
        saveCache(currnIndex)//saving current index
        var fileExist =
            ImagesExist() //checking if the images are available in internalStorage of the app
        if (fileExist) {
            //Loading images from Files of the phone
            if (count == 0) {//statement to make sure the images are loaded from file once, to increase efficiency

                var Li = LoadImages()
                Li.start() //start Thread
                Li.join() //waiting for thread to finish
                imgList = Li.getImageList()
                count++
            }
            imgbit = imgList[currnIndex].getBitmap()   // getting bitmap of the image to be viewed

        }

        var id: Int


        if (imgbit != null) {
            imageView.setImageBitmap(imgList[currnIndex].getBitmap()) //displaying image loaded from internal storage in Bitmap format


        } else {
            id = resources.getIdentifier(
                letters[currnIndex],
                "drawable",
                packageName
            ) //getting id of the image which is in drawables
            imageView.setImageResource(id) //displaying image from drawables

        }


        val overViewbtn =
            findViewById<Button>(R.id.overViewbtn)    //getting reference of overview button creation


        //Goes back to the overview page
        overViewbtn.setOnClickListener {
            saveCache(-1)
            var intent = Intent(this, MainActivity::class.java)

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            // resetting cache
            startActivity(intent)
        }

        val firstbtn = findViewById<Button>(R.id.firstbtn) //first button creation
        //Shows the first letter of alphabet
        firstbtn.setOnClickListener {
            currnIndex = 0
            saveCache(currnIndex)
            if (fileExist) { //checking if images have been loaded from internal memory
                imageView.setImageBitmap(imgList[currnIndex].getBitmap())
            } else {
                id = resources.getIdentifier(
                    letters[currnIndex],
                    "drawable",
                    packageName
                ) //getting id of the image which is in drawables
                imageView.setImageResource(id) //displaying image from drawables

            }

        }

        val lastbtn = findViewById<Button>(R.id.lastbtn)    //last button creation
        //Shows the last letter of alphabet
        lastbtn.setOnClickListener {

            currnIndex = 25
            saveCache(currnIndex)
            if (fileExist){//checking if images have been loaded from internal memory
                imageView.setImageBitmap(imgList[currnIndex].getBitmap())
        }else{
                id = resources.getIdentifier(letters[currnIndex],"drawable",packageName) //getting id of the image which is in drawables
                imageView.setImageResource(id) //displaying image from drawables

            }

        }


        val prevbtn = findViewById<Button>(R.id.prevbtn)    //previous button creation
        //Allows to move to
        prevbtn.setOnClickListener {

            if (currnIndex != 0) {
                //get current index of name
                currnIndex--//next index for next letter
                saveCache(currnIndex)
                if (fileExist){
                    imageView.setImageBitmap(imgList[currnIndex].getBitmap())
                }else {
                    id = resources.getIdentifier(
                        letters[currnIndex],
                        "drawable",
                        packageName
                    ) //getting id of the image which is in drawables
                    imageView.setImageResource(id) //displaying image from drawables
                }


                } else {
                var duration = Toast.LENGTH_SHORT
                Toast.makeText(
                    applicationContext,
                    "You are at the first letter of the Alphabet!",
                    duration
                ).show()
                saveCache(currnIndex)

            }
        }

        val nextbtn = findViewById<Button>(R.id.nextbtn)    //next button creation
        nextbtn.setOnClickListener {

            if (currnIndex != 25) {
                //get current index of name
                currnIndex++//next index for next letter
                saveCache(currnIndex)
                if (fileExist){
                    imageView.setImageBitmap(imgList[currnIndex].getBitmap())
                }else {
                    id = resources.getIdentifier(
                        letters[currnIndex],
                        "drawable",
                        packageName
                    ) //getting id of the image which is in drawables
                    imageView.setImageResource(id) //displaying image from drawables
                }


            } else {

                saveCache(currnIndex)
                Toast.makeText(
                    applicationContext,
                    "You are at the last letter of the Alphabet!",
                    Toast.LENGTH_LONG
                ).show() // display a message
            }
        }
    }



    private fun ImagesExist(): Boolean {
        var path = "/storage/emulated/0/Alphabets/"
        var imgFile = File(path)
        return imgFile.exists()

    }


    override fun onDestroy() {
        super.onDestroy()

        saveCache(currnIndex) //Index value of the currently viewed letter


    }

    fun saveCache(index: Int) {
        var path = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)

        var file = File(path, "cache.txt")
        var fW = FileWriter(file)
        if (index == -1) {
            currnIndex = -1
            fW.write(" ")
            fW.close()
        } else {
            fW.write(currnIndex.toString())
            fW.close()
        }
    }

}