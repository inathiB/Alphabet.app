package com.example.alphabetbook

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.FileWriter


class MainActivity : AppCompatActivity() {
    var permission: Boolean = false                 //App permission variable

    //Creation of activities when app is started
    override fun onCreate(savedInstanceState: Bundle?) {



        //Acess files in internal storage if user gives permission
        //Acess files in internal storage if user gives permission

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, Array(1) {
                Manifest.permission.READ_EXTERNAL_STORAGE
            }, 121)  //giving permission
        }


        var index = checkCache() //getting cache or data saved when app was closed previous

        if (index!=-1){//checking if there was data which has been saved when the app was closed previously
            var intent = Intent(applicationContext, AlphabetActivity2::class.java)
            intent.putExtra("cur",index) //passing the index of the letter to be displayed
            startActivity(intent) //calling AlphabetActivity2( going to the next activity)
        }else{ //no data saved , app was closed from at OverView page
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            //loading letters in an array

            var beta = Array<String>(26) { "" }
            var l = 65//Capital "A" unicode
            for (i in 0..25) {
                beta[i] = Character.toString(l.toChar()) //converting the unicode to Character
                l++

            }
            //loading contents of beta array into an ArrayAdapter
            var adapter = ArrayAdapter<String>(
                applicationContext,
                android.R.layout.simple_dropdown_item_1line, //format of loading items is dropdown
                beta
            )
            //getting reference to gridview
            val gridview = findViewById(R.id.gridview) as GridView
            //passing adapter with letters to gridview adapter so that they can be loaded and siplayed on the screen
            gridview.adapter = adapter


            gridview.setOnItemClickListener { adapterView, view, i, l ->

                var intent = Intent(applicationContext, AlphabetActivity2::class.java)
                //passing the name of the letter to be displayed to AlphabetActivity2
                intent.putExtra("cur", i) // passing the current index
                startActivity(intent) // invoking AlphabetActivity2

            }
        }
    }

    //Store user response to permission request
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 121 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            permission = true //granting the permission so that the app can access and use phone resource such as pictures

        }
    }
    fun checkCache():Int{
        var file =File("/storage/emulated/0/Android/data/com.example.alphabetbook/files/Documents/cache.txt")
        var br:BufferedReader
        if (file.exists()) {
             br = BufferedReader(FileReader(file))
        }else{
            createCacheFile()
            br = BufferedReader(FileReader(file))
        }
        var content =br.readLine() //reading the contents of the text file
        if(content.equals(" ")){ //checking if the textFile is as an empty space
            return -1
        }
        return content.toInt() //returning the current index


        return 0
    }
    fun createCacheFile(){
        var path =  getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)

        var file = File(path,"cache.txt")
        var fW = FileWriter(file)
        fW.write(" ")
        fW.close()

    }


}



