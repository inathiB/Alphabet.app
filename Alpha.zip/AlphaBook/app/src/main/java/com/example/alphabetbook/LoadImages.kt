package com.example.alphabetbook

import android.graphics.BitmapFactory
import java.io.File

class LoadImages:Thread() {
    var imgList = Array(26) { myImage() } // Array list of myImage objects

    override fun run() {
        var path: String

        var beta = Array<String>(26) { "" }
        var l = 65//starting unicode value
        for (i in 0..25) {
            beta[i] = Character.toString(l.toChar())
            // i have created Alphabets folder in my internal storage of my phone and loaded the alphabet pictures
            // i have renamed the images to smaller letter if its image of letter "A" its named a.gif and i did this to all letters
            path = "/storage/emulated/0/Alphabets/" + beta[i].lowercase() + ".gif" //the path to letters in my phone

            var imgFile = File(path)

            if (imgFile.exists()) {
                var imag: myImage = myImage()

                // on below line we are creating an image bitmap variable
                // and adding a bitmap to it from image file.
                var imgBitmap = BitmapFactory.decodeFile(imgFile.absolutePath)
                if (imgBitmap != null) {
                    imag.add(beta[i].lowercase(), imgBitmap)
                    imgList[i] = imag
                }
            }

            l++

        }

    }
    fun getImageList(): Array<myImage> {
        return imgList
    }

}