package com.example.alphabetbook

import android.graphics.Bitmap
import java.io.Serializable
//To store bitmap images and alphabet letters in an object that will be stored in an array for later access
class myImage() : Serializable {
    var name: String = ""
    var bitmap: Bitmap? = null

    //To get alphabet letter
    @JvmName("getName1")
    fun getName(): String {
        return name // name of image
    }
    //To get bitmap value
    @JvmName("getBitmap1")
    fun getBitmap(): Bitmap? {
        return bitmap //bitmap of the image

    }
    //To add alphabet  and bitmap to the object
    fun add(name: String, bitmap: Bitmap) {
        this.name = name
        this.bitmap = bitmap
    }


}